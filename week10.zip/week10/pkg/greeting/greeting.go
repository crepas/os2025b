package greeting

import "fmt"

func Hello(){
	fmt.Println("Hello, World!")
}

func Hi(){
	fmt.Println("Hi there!")
}